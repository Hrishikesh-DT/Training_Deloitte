package p1;
import java.util.*;

public class Generic1 {

	public static void main(String[] args) {

		ArrayList al = new ArrayList();
		al.add("pq");
		String s1 = (String) al.get(0);
		System.out.println("al = "+ al);
		ArrayList<String> list = new ArrayList<String>();
		list.add("abc");
		//list.add(32); //not allowed
		String s = list.get(0);
		System.out.println("s = "+s);
		
		ArrayList<Integer> list1 = new ArrayList<Integer>();
		list1.add(10);
		Integer s2 = list1.get(0);
		System.out.println("s2 = "+s2);

	}

}
