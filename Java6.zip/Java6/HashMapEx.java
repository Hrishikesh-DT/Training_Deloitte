package p1;
import java.util.*;


public class HashMapEx {
	public static void main(String ar[]) {
	HashMap hm= new HashMap();
	
	//put elements to map
	hm.put("pp", new Double(5434.22));
	hm.put("aa", new Double(54.22));
	hm.put("dd", new Double(34.22));
	hm.put("pp", (54.92));
	
	//get set of entries
	
	Set set= hm.entrySet();
	
	Iterator i= set.iterator();
	
	while(i.hasNext()) {
		Map.Entry m= (Map.Entry)i.next();
		System.out.println(m.getKey()+":");
		System.out.println(m.getValue());
	}
	
	

	
}
}
