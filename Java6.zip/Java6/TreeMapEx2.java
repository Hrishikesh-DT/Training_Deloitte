package p1;
import java.util.*;

class Book2{
	
	int id;
	String title, author, publisher;
	int qt;
	Book2(int id,String title, String author,String publisher,int qt){
		this.id= id;
		this.title=title;
		this.author=author;
		this.publisher=publisher;
		
	}
}
public class TreeMapEx2 {
	public static void main(String ar[]) {
		Map<Integer,Book2> map= new TreeMap<Integer,Book2>();
		
		Book2 b1 = new Book2(101,"Let us C","Kanetkar","BPB",8);
		Book2 b2 = new Book2(102,"Data Comm. & Networks","Forouzan","Mc graw hill",4);
		Book2 b3 = new Book2(103,"OS","Galvin","Wiley",6);
		map.put(1,b1);
		map.put(2,b2);
		map.put(3,b3);
		
		System.out.println("Tree Map\n");
		System.out.println("For each o/p");
		for(Map.Entry<Integer, Book2> entry1: map.entrySet()) {
			int key =entry1.getKey();
			Book2 b = entry1.getValue();
			System.out.println(key+"Details:");
			System.out.println(b.id+" "+b.title+" " +b.author+" "+b.publisher);
			}
		System.out.println("\nIterator o/p");
		
		Set set = map.entrySet();
		
		Iterator i= set.iterator();
		
		while(i.hasNext()) {
			Map.Entry m= (Map.Entry)i.next();
			Book2 bb = (Book2)m.getValue();
			System.out.println(m.getKey()+":");
			System.out.println(bb.id+" "+bb.title+" " +bb.author+" "+bb.publisher);
		}
	}
}
