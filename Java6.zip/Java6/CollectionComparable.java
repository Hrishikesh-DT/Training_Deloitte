package p1;
import java.util.*;

class Emp2 implements Comparable<Emp2>{
	int id;
	String name;
	Emp2(int id, String name)
	{
		this.id =id;
		this.name =name;
	}
	
	public int compareTo(Emp2 e)
	{
		
		if(id ==e.id) return 0;
		else if(id > e.id) return 1;
		else return -1;
		 
		
		//return name.compareTo(e.name);
	}
	
	public String toString()
	{
		return id+" "+name;
	}
}
/*
class MyComparator implements Comparator<Emp>
{
	public int compare(Emp e1, Emp e2)
	{
		
		return e1.name.compareTo(e2.name);
	}
}
*/

public class CollectionComparable {

	public static void main(String[] args) {

		Emp2 e1 =new Emp2(10,"punita");
		Emp2 e2 =new Emp2(1,"ae");
		Emp2 e3 =new Emp2(77,"aa");
		
		List<Emp2> s1 = new ArrayList<Emp2>();
		s1.add(e1);
		s1.add(e2);
		s1.add(e3);
		System.out.println(s1);
		Collections.sort(s1);
		System.out.println(s1);
	}

}

