package p1;

import java.util.ArrayList;
import java.util.Iterator;

class Student{
	int no;
	String name;
	int age;
	Student(int no,String name,int age)
	{
		this.no =no;
		this.name = name;
		this.age = age;
	}
	
}

public class ArrayListEx2 {

	public static void main(String[] args) {
		Student s1 = new Student(101,"amit",23);
		Student s2 = new Student(102,"sunita",21);
		Student s3 = new Student(103,"harsh",25);
		ArrayList a1 = new ArrayList();
		//System.out.println("Initial size of ArrayList: "+a1.size());
		a1.add(s1);
		a1.add(s2);
		a1.add(s3);
		
		Iterator itr = a1.iterator();
		while(itr.hasNext())
		{
			Student st = (Student)itr.next();
			System.out.println(st.no+" "+st.name+" "+st.age);
			if(st.no == 102)
			{
				itr.remove();
			
			}
			if(st.no == 103)
			{
				st.name = "Hrishi";
			}
		}
		System.out.println("AFter modifications:");
		Iterator itr1 = a1.iterator();
		while(itr1.hasNext())
		{
			Student st = (Student)itr1.next();
			System.out.println(st.no+" "+st.name+" "+st.age);
			
		}
	}

}
