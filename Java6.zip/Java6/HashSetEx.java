package p1;
import java.util.*;
public class HashSetEx {
	
		public static void main(String ar[]) {
		HashSet hm= new HashSet();
		
		//put elements to map
		hm.add("B");
		hm.add("E");
		hm.add("F");
		hm.add("A");
		
		//get set of entries
		
		
		
		Iterator i= hm.iterator();
		
		while(i.hasNext()) {
			
			System.out.println(i.next());
			
		}
		
		
}
}
