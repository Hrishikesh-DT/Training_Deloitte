package p1;
import java.util.*;



public class ArrayListEx {

	public static void main(String[] args) {

		ArrayList a1 = new ArrayList();
		System.out.println("Initial size of ArrayList: "+a1.size());
		a1.add('C');
		a1.add('B');
		a1.add('A');
		a1.add("Dh");
		a1.add('E');
		a1.add('F');
		System.out.println("ArrayList is: "+ a1);
		a1.add(1,"A2");
		System.out.println("ArrayList is: "+ a1);
		
		a1.remove(2);
		System.out.println("ArrayList is: "+ a1);
		a1.remove("Dh");
		System.out.println("ArrayList is: "+ a1);
		
		System.out.println("New size of ArrayList after additions and deletions: "+a1.size());
		
		Iterator itr = a1.iterator();
		while(itr.hasNext())
		{
			System.out.println(itr.next());
			
		}
		System.out.println("\nUsing for each");
		for(Object obj : a1)
		{
			System.out.println(obj);
		}
	}

}
