package p1;
import java.util.*;

class Book1
{
	
	int id;
	String title, author, publisher;
	int qt;
	Book1(int id,String title, String author,String publisher,int qt)
	{
		this.id= id;
		this.title=title;
		this.author=author;
		this.publisher=publisher;
		
	}
}
public class HashMapEx2 {
	public static void main(String ar[]) {
		Map<Integer,Book1> hm= new HashMap<Integer,Book1>();
		/*
		Book1 b1 = new Book1(101,"Let us C","Yashwant Kanetkar","BPB",8);
		Book1 b2 = new Book1(102,"Let us Java","Yashwant Kanetkar","BPB",10);
		Book1 b3 = new Book1(103,"Let us Python","Yashwant Kanetkar","BPB",11);
		*/
		Book1 b1 = new Book1(101,"Let us C","Kanetkar","BPB",8);
		Book1 b2 = new Book1(102,"Data Comm. & Networks","Forouzan","Mc graw hill",4);
		Book1 b3 = new Book1(103,"OS","Galvin","Wiley",6);
		hm.put(1,b1);
		hm.put(2,b2);
		hm.put(3,b3);
		
		System.out.println("For each o/p");
		for(Map.Entry<Integer, Book1> entry1: hm.entrySet()) {
			int key =entry1.getKey();
			Book1 b = entry1.getValue();
			System.out.println(key+"Details:");
			System.out.println(b.id+" "+b.title+" " +b.author+" "+b.publisher);
			}
		System.out.println("Iterator o/p");
		
		Set set = hm.entrySet();
		
		Iterator i= set.iterator();
		
		while(i.hasNext()) {
			Map.Entry m= (Map.Entry)i.next();
			Book1 bb = (Book1)m.getValue();
			System.out.println(m.getKey()+":");
			System.out.println(bb.id+" "+bb.title+" " +bb.author+" "+bb.publisher);
		}
	}
}
