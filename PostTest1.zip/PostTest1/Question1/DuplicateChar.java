import java.util.Scanner;
public class DuplicateChar {
	
	public void findDuplicates(String str)
	{
		str = str.toLowerCase();
		Integer[] array = new Integer[26];
		int count_arr[] = new int[str.length()];
		char c;
		for(int i=0 ; i<str.length();i++)
		{
			c = str.charAt(i);
			int p = c -'a';
	        if(array[p]==null) {
	            array[p]= 1;
	        }else {
	            array[p]+= 1;
	        }
			//System.out.println(c+"now");
			
		}
	        for(int m=0; m<array.length; m++) {
	            if(array[m]!=null && array[m]>1) {
	                char ch = (char)(97+m);
	                System.out.println("Character '"+ch+"' is repeated "+array[m]+" times.");
	            }
	        }
	       
	}
	
	public static void main(String[] args) {

		Scanner sc =new Scanner(System.in);
		System.out.print("Enter the String: ");
		String input_str = sc.next();
		DuplicateChar d  = new DuplicateChar();
		d.findDuplicates(input_str);
		
	}
 
}
