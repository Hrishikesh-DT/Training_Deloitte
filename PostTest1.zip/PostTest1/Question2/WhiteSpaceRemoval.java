import java.util.Scanner;
public class WhiteSpaceRemoval {

	public void removeWhiteSpaces(String str)
	{
		
		for(int i=0;i<str.length();i++)
		{
			if(str.charAt(i)==' ')
			{
				str = str.substring(0,i)+ str.substring(i+1,str.length());
			}
		}
		System.out.println("Modified string without spaces: "+str);
	}
	
	
	public static void main(String[] args) {
		
		
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the String: ");
		String input_str=sc.nextLine();
		
		WhiteSpaceRemoval w =new WhiteSpaceRemoval();
		w.removeWhiteSpaces(input_str);
		
	}

}
