package p;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class test 
{

	public static void main(String ar[]) 
	{

		//Resource re= new ClassPathResource("applicationContext.xml");
		//BeanFactory fact= new XmlBeanFactory(re);
		ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
		

		Quest q= (Quest)context.getBean("q1");		
		q.dis();

	}
}