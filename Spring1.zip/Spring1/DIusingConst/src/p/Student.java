package p;

public class Student {

	private String name;
	private int id;

	public Student() {System.out.println("def constructor");}
	public Student(int id)
	{
		this.id=id;
	}
	
	public Student(String fn,int id)
	{
		this.id=id;
		this.name= fn;
	}
	void displayinfo()
	{
		System.out.print("Hello "+id+" " +name);
		
	}
}
