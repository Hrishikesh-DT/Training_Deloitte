package p;
import java.util.*;

public class Quest {

	private int id;
	private String name;
	private List<String> courses;
	
	Quest(){}
	
	
	void dis()
	{
		System.out.print(id+"  "+name+" ");
		Iterator<String> it=courses.iterator();
		System.out.println("\nCourses are: ");
		while(it.hasNext())
		{
			System.out.println(it.next());
		}
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public List<String> getCourses() {
		return courses;
	}


	public void setCourses(List<String> courses) {
		this.courses = courses;
	}

	
}
