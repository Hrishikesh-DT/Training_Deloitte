package p;

public class A {

	B b1;

	A(B b1)
	{
		this.b1 = b1;
	}
	
	void show()
	{
		System.out.println("class A test by constructor");
		b1.show1();
	}
}
