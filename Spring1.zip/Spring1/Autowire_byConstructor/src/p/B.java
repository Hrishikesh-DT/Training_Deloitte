package p;

public class B {

	
	
	
	void show1()
	{
		System.out.println("class B");
	}
	
}
