package p;

public class A {

	B b1;

	public B getB1() {
		return b1;
	}

	public void setB1(B b1) {
		this.b1 = b1;
	}
	
	void show()
	{
		System.out.println("class A test by name");
		b1.show1();
	}
}
