package contextServ;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Context2 extends HttpServlet{
	
	ServletContext ctx = null;
	public void init(ServletConfig sc) throws ServletException
	{
		ctx = sc.getServletContext();
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response){
		
		
		try {
			PrintWriter out = response.getWriter();
			String s = (String)ctx.getAttribute("ob");
			
			out.println("Your name is "+s);
			
			}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}

}

