
class One
{
	void show() {
		System.out .println("Class One");
	}
	
}


class Two extends One{
	void show() {
		super.show();
		System.out .println("Class Two");
	}
}

class Hierarchy extends One
{
	
	void show() 
	{
		super.show();
		System.out .println("Class Hierarchy");
	}
	
	public static void main(String []args) {
		
		Hierarchy c1 = new Hierarchy();
		c1.show();
	}
	
	
}