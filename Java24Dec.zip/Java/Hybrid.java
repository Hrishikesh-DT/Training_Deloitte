
class AA
{
	void show() {
		System.out .println("Class AA");
	}
	
}


class BB extends AA{
	void show() {
		super.show();
		System.out .println("Class BB");
	}
}

class CC extends BB{
	void show() {
		super.show();
		System.out .println("Class CC");
	}
	
}

class Hybrid extends BB
{
	
	void show() 
	{
		super.show();
		System.out .println("Class Hybrid");
	}
	
	public static void main(String []args) {
		
		Hybrid c1 = new Hybrid();
		c1.show();
	}
	
	
}