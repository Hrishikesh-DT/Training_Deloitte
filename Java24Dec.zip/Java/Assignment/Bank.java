package Assignment;

public class Bank {

	String name;
	int acc_no;
	String acc_type;
	int balance;
	
	Bank(String name,int acc_no,String acc_type,int balance){
		this.name = name;
		this.acc_no = acc_no;
		this.acc_type = acc_type;
		this.balance = balance;
	}
	
	public void setName(String str) {
		name = str;	
	}
	
	public void setAccNo(int num) {
		acc_no = num;
	}
	
	public void setAccType(String type) {
		acc_type = type;
	}
	
	public void setBalance(int bal) {
		balance =bal;
	}
	
	public void deposit(int amt) {
		balance = balance + amt;
		System.out.println("Amount deposited Rs."+amt+"\nNew Balance: "+balance);
	
	}
	
	public void withdraw(int amt) {
		if(balance - amt > 5000) {
			balance = balance - amt;
			System.out.println("Amount withdrawn Rs."+amt+"\nNew Balance: "+balance);
		}
		else {
			System.out.println("Cannot withdraw Rs."+amt);
		}
		
	}
	
	public void name_Bal(){
		System.out.println("Name: "+name+"\nBalance: "+balance);
		
	}
	
	public static void main(String[] args) {
		
		String name = args[0];
		int acc_no = Integer.parseInt(args[1]);
		String acc_type= args[2];
		int balance = Integer.parseInt(args[3]);
		
		Bank b = new Bank(name,acc_no,acc_type,balance); //"Hrishikesh",0001,"Current",50000
		b.name_Bal();
		b.deposit(10000);
		b.withdraw(5000);
		
	}

}
