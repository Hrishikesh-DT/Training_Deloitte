package Assignment;
import java.util.Scanner;

class Book{
	String author;
	String title;
	int price;
	String publisher;
	int stock_pos;
	
	Book(String author,String title,int price,String publisher,int stock_pos){
		this.author = author;
		this.title= title;
		this.price = price;
		this.publisher = publisher;
		this.stock_pos = stock_pos;
	}
	
	
	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		
		Book b[] = new Book[4];
		
		b[0] = new Book("auth1","title1",100,"publish1",10);
		b[1] = new Book("auth2","title2",150,"publish2",12);
		b[2] = new Book("auth3","title3",120,"publish3",15);
		b[3] = new Book("auth4","title4",140,"publish1",15);
		
		//Book[] b = {b1,b2,b3,b4};
		String req_auth = sc.next();//args[0];
		String req_title = sc.next();//args[1];
		
		
		Book bx = null;
		for (int i=0; i<b.length ; i++) {
			if (b[i].author.equals(req_auth) && b[i].title.equals(req_title)) {
				bx = b[i];
				System.out.println("Requested book is available");
			}
		}
		if(bx == null) {
			System.out.println("Requested book is not available");
		}
		else {
			System.out.println("Author: "+bx.author+"\nTitle: "+bx.title+"\nPrice: "+bx.price+"\nPublisher: "+bx.publisher+"\nStock position: "+bx.stock_pos+"\n\n");
			System.out.println("Enter the number of copies required:");
			int num_copies = sc.nextInt();
			if (bx.stock_pos < num_copies) {
				System.out.println("Required copies not in stock");
			}
			else {
				System.out.println("Total cost for required copies: "+ (bx.price*num_copies));
			}
			
		}
		
		
	}
	
	
	
	
	
}