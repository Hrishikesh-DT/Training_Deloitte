class A{
	void show() {
		System.out .println("Class A");
	}
	
}


class Single_Inheritance extends A
{
	
	void show() 
	{
		super.show();
		System.out .println("Class Single_Inheritance");
	}
	
	public static void main(String []args) {
		
		Single_Inheritance c1 = new Single_Inheritance();
		c1.show();
	}
	
	
}