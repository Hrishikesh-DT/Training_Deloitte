class Constructor{
	int x;
	static int p;
	
	Constructor(){
		
		x=20;
	}
	
	Constructor(int x){
		this.x = x;
	}
	
	void show() {
		
		System.out.println("show()");
		System.out.println("x="+x);
	}
	
	public static void main(String args[])
	{
		Constructor c1 = new Constructor();
		c1.show();
		
		Constructor c2 = new Constructor(30);
		c2.show();
		
		
		
	}
	
	
	
}