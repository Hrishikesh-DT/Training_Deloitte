class X{
	
	
	void show() {
		
		
	}
	
}


class Y extends X{
	void show()
	{
		System.out.println("Class Y");
	}
	
}

class Dynamic_method_dispatch extends X{
	
	void show() {
		System.out.println("Class Z");
	}
	
	public static void main(String args[]) {
		
		X x  = new Y();
		x.show();
		X x2 = new Dynamic_method_dispatch();
		x2.show();
		
	}
}