

class C
{
	void show() {
		System.out .println("Class C");
	}
	
}


class B extends C{
	void show() {
		super.show();
		System.out .println("Class B");
	}
}

class Multilevel extends B
{
	
	void show() 
	{
		super.show();
		System.out .println("Class Multilevel");
	}
	
	public static void main(String []args) {
		
		Multilevel c1 = new Multilevel();
		c1.show();
	}
	
	
}