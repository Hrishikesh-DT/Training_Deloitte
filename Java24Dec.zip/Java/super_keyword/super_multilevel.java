package super_keyword;
class T{
	int k;
	T(int r){
		k=r;
	}
}


class AA extends T{
	int x;
	AA(int p){
		super(77);
		x=p;
	}
	
	void show() {
		System.out.println("class AA x="+x);
		System.out.println("class AA k="+k);

	}
	
	
}

public class super_multilevel extends AA {

	int y,z;
	
	
	public super_multilevel() {
		super(30);
		y = 90;
		z = 100;
		
		
	}
	void show() {
		System.out.println("class C x="+x);
		System.out.println("class C y="+y);
		System.out.println("class C z="+z);
		System.out.println("class C k="+k);

	}
	

	public static void main(String[] args) {

		super_multilevel c1 = new super_multilevel();
		c1.show();
		
	}

}
