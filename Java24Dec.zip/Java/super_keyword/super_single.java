package super_keyword;

class A{
	int x;
	A(int p){
		x=p;
	}
	
	void show() {
		System.out.println("class A x="+x);
		System.out.println("class A x="+x);

	}
	
	
}

public class super_single extends A {

	int y,z;
	
	
	public super_single() {
		super(30);
		y = 90;
		z = 100;
		
		
	}
	void show() {
		System.out.println("class C x="+x);
		System.out.println("class C y="+y);
		System.out.println("class C z="+z);

	}
	

	public static void main(String[] args) {

		super_single c1 = new super_single();
		c1.show();
		
	}

}
