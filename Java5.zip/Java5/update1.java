package jdbc;
import java.sql.*;
import java.util.Scanner;

public class update1 {

	void show()
	{
		Connection conn = null;
		String url = "jdbc:mysql://localhost:3306/";
		String dbName = "db1";
		String driver = "com.mysql.jdbc.Driver";
		String username = "root";
		String password = "root";
		
		try
		{
			Class.forName(driver);
			conn = DriverManager.getConnection(url+dbName,username,password);
			System.out.println("Connected to database");

			PreparedStatement ps = conn.prepareStatement("update emp3 set ename = ? where ecode=?");
			Scanner sc = new Scanner(System.in);
			String s =sc.next();
			String s1 = sc.next();
			
			ps.setString(1, s);
			ps.setString(2,s1);
			
			int x  = ps.executeUpdate();
			System.out.println(x +" rows updated");

			conn.close();
			System.out.println("Disconnected from database");

		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Exception occured");
		}
	}
	public static void main(String[] args) {
			
		update1 j = new update1();
		j.show();
	}

}

