package jdbc;
import java.sql.*;
import java.util.Scanner;

public class delOracle {
	
	
	
	public static void main(String[] args) {
		System.out.println("---------Oracle JDBC Connection Testing--------------");
		Connection connection = null;
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","hr","hr");
			PreparedStatement ps = connection.prepareStatement("delete from emp3 where ecode = ?");
			Scanner sc = new Scanner(System.in);
			String s =sc.next();
			//String s1 = sc.next();
			
			ps.setString(1, s);
			//ps.setString(2,s1);
			
			int x  = ps.executeUpdate();
			System.out.println(x +" rows deleted");

			
			connection.commit();
			connection.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("COnnection Failed! Check output console");
			return;
		}
		
		if(connection!=null)
		{
			System.out.println("You made it, take control of your database now!");
			
		}
		else {
			System.out.println("Failed to make connection!");
		}
	}

}
