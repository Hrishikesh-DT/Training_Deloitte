package jdbc;
import java.sql.*;

public class select_oracle {
	
	
	
	public static void main(String[] args) {
		System.out.println("---------Oracle JDBC Connection Testing--------------");
		Connection connection = null;
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","hr","hr");
			Statement sm = connection.createStatement();
			ResultSet rs = sm.executeQuery("select * from emp3");
			while(rs.next())
			{
				String f1 =rs.getString("ecode");
				String f2 = rs.getString("ename");
				System.out.println(f1);
				System.out.println(f2);
			}
			//connection.commit();
			connection.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("COnnection Failed! Check output console");
			return;
		}
		
		if(connection!=null)
		{
			System.out.println("You made it, take control of your database now!");
			
		}
		else {
			System.out.println("Failed to make connection!");
		}
	}

}
