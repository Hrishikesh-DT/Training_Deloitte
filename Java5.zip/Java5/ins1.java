package jdbc;
import java.sql.*;
import java.util.Scanner;

public class ins1 {

	void show()
	{
		Connection conn = null;
		String url = "jdbc:mysql://localhost:3306/";
		String dbName = "db1";
		String driver = "com.mysql.jdbc.Driver";
		String username = "root";
		String password = "root";
		
		try
		{
			Class.forName(driver);
			conn = DriverManager.getConnection(url+dbName,username,password);
			System.out.println("Connected to database");

			PreparedStatement ps = conn.prepareStatement("insert into emp3 values(?,?)");
			Scanner sc = new Scanner(System.in);
			String s =sc.next();
			String s1 = sc.next();
			
			ps.setString(1, s);
			ps.setString(2,s1);
			
			int x  = ps.executeUpdate();
			System.out.println(x +" rows inserted");

			conn.close();
			System.out.println("Disconnected from database");

		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Exception occured");
		}
	}
	public static void main(String[] args) {
			
		ins1 j = new ins1();
		j.show();
	}

}

