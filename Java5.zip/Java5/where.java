package jdbc;
import java.sql.*;
import java.util.Scanner;

public class where {

	void show()
	{
		Connection conn = null;
		String url = "jdbc:mysql://localhost:3306/";
		String dbName = "db1";
		String driver = "com.mysql.jdbc.Driver";
		String username = "root";
		String password = "root";
		
		try
		{
			Class.forName(driver);
			conn = DriverManager.getConnection(url+dbName,username,password);
			Statement sm = conn.createStatement();
			Scanner sc = new Scanner(System.in);
			String s =sc.next();
			String s1 = sc.next();
			ResultSet rs = sm.executeQuery("select * from emp3 where ecode='"+s+"' and ename='"+s1+"'");
			while(rs.next())
			{
				String f1 =rs.getString(1);
				String f2 = rs.getString(2);
				System.out.println(f1);
				System.out.println(f2);
			}
			conn.close();
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Exception occured");
		}
	}
	public static void main(String[] args) {
			
		where j = new where();
		j.show();
	}

}
