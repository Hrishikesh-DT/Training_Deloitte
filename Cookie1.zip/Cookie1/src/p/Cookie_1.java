package p;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Cookie_1 extends HttpServlet{
	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response){
		
		
		try {
			PrintWriter out = response.getWriter();
			String s = request.getParameter("uname");
			String s1 = request.getParameter("lname");
			
			Cookie cr = new Cookie("user",s);
			Cookie cr2 = new Cookie("user2",s1);
			
			response.addCookie(cr);
			response.addCookie(cr2);
			
			
			out.println("Cookie containing username is stored in your browser!");
			out.print("<html><body>");
			out.print("<form name='f1' method='get' action='c'>");
			out.print("<input type='submit' value='click' name='click'>");
			out.print("</form>");
			out.print("</body></html>");
			
			}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}

}

