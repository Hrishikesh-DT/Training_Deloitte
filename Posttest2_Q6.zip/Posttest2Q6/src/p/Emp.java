package p;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Emp extends HttpServlet {
	
	String fname;
	String lname;
	String empId;
	String address;
	static int id = 1;
	
	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public String getEmpId() {
		return empId;
	}

	public void setEmpId(String empId) {
		this.empId = empId;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String generateEmpId(String fname, String lname)

	{
		String s = fname.substring(0,2)+lname.substring(0,2)+String.format("%03d", Emp.id);
		Emp.id++;
		return s;
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response){
		
		Connection conn = null;
		String url = "jdbc:mysql://localhost:3306/";
		String dbName = "db1";
		String driver = "com.mysql.jdbc.Driver";
		String username = "root";
		String password = "root";
		
		try {
			PrintWriter out = response.getWriter();
			
			Class.forName(driver);
			conn = DriverManager.getConnection(url+dbName,username,password);
			
			out.print("Connected to database!<br>");
			Statement sm1 = conn.createStatement();
			ResultSet rs1 = sm1.executeQuery("select count(*) from emp");
			rs1.next();
			int row_count = rs1.getInt(1);
			Emp.id = row_count+1;
			
			String fname =request.getParameter("fname");
			String lname = request.getParameter("lname");
			String addr = request.getParameter("addr");
			String emp_id = generateEmpId(fname,lname);
			
			Emp e1 = new Emp();
			e1.setFname(fname);
			e1.setLname(lname);
			e1.setAddress(addr);
			e1.setEmpId(emp_id);
			
			Class.forName(driver);
			conn = DriverManager.getConnection(url+dbName,username,password);
			
			
			
			PreparedStatement ps = conn.prepareStatement("insert into emp values(?,?,?,?)");
			ps.setString(1,e1.getEmpId());
			ps.setString(2,e1.getFname());
			ps.setString(3,e1.getLname());
			ps.setString(4,e1.getAddress());
			int x  = ps.executeUpdate();
			out.print(x +" rows inserted<br>");
			
			Statement sm = conn.createStatement();
			ResultSet rs = sm.executeQuery("select * from emp");
			out.print("<table border=1 bgcolor=lightblue>");
			out.print("<th>EmpId</th><th>First_Name</th><th>Last_Name</th><th>Address</th>");
			
			while(rs.next())
			{
				String f1 = rs.getString(1);
				String f2 = rs.getString(2);
				String f3 = rs.getString(3);
				String f4 = rs.getString(4);
				out.print("<tr><td>"+f1+"</td><td>"+f2+"</td><td>"+f3+"</td><td>"+f4+"</td></tr>");
				//System.out.println(f2);
			}
			
			out.print("</table>");
			conn.close();
			out.print("Disconnected from database.");
			}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}

}