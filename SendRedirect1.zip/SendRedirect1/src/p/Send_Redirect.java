package p;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Send_Redirect extends HttpServlet{
	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response){
		
		
		try {
			PrintWriter out = response.getWriter();
			String s = request.getParameter("uname");
			String s1 = request.getParameter("password");
			
			if(s.equals("abc") && s1.equals("abc"))
			{
				out.print("Valid user!");
				
			}
			else
			{
				out.print("Invalid user");
				response.sendRedirect("Error.html");
			}
			/*out.println("Your name is stored!");
			out.print("<form name='f1' method='get' action='c2'>");
			out.print("<input type='submit' value='click' name='click'>");
			out.print("</form>");
			*/
			}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}

}

