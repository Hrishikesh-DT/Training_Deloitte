package p;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Url2 extends HttpServlet{
	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response){
		
		
		try {
			PrintWriter out = response.getWriter();
			String s1 = request.getParameter("var1");
			
			out.println("s1 = "+s1);
			
			}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}

}

