package myJdbc.SprinBootJdbc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SprinBootJdbcApplication {

	public static void main(String[] args) {
		SpringApplication.run(SprinBootJdbcApplication.class, args);
		System.out.println("Done!!");
	}

}
