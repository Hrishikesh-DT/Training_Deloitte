package myJdbc.SprinBootJdbc.p;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ContactService
{
	@Autowired
	ContactRepository cr;
	
	public List<Contact> listAll()
	{
		return cr.findAll();
	}
	
	public Contact getId(String id)
	{
		return cr.findById(id).get();
	}
	public void saveContact(Contact ct)
	{
		cr.save(ct);
	}
	public void deleteContact(String id)
	{
		cr.deleteById(id);
	}
}
