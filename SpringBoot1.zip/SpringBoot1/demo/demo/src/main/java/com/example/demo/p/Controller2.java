package com.example.demo.p;

import java.awt.List;
import java.util.*;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class Controller2 {
	
	
	@RequestMapping("/h")
	public String show()
	{

		return "First";
	}
	
	@RequestMapping("/s")
	public String dis2(@RequestParam("ename")String ename,@RequestParam("salary")String salary,ModelMap m)
	{
		m.put("s1", ename);
		m.put("s2",salary);
		
		
		return "Second";
	}
	

}
