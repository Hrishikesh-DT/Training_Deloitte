package pretest;
import java.util.Scanner;

public class Pretest {

	
	public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
		
		//String str = "hrishi";
		String str =sc.next();
		String str2 ="";
		int count =0;
		for(int i = str.length()-1;i>= 0;i--)
		{
		str2 = str2 + str.charAt(i);
		if(str.charAt(i)=='a' || str.charAt(i)=='A' ||str.charAt(i)=='e' ||str.charAt(i)=='E' ||str.charAt(i)=='i' || str.charAt(i)=='I' || str.charAt(i)=='o' || str.charAt(i)=='O' || str.charAt(i)=='u' || str.charAt(i)=='U')
		{
			count++;
		}
		}
		System.out.println(str2);
		System.out.println("Number of vowels: "+count);

	}
}
