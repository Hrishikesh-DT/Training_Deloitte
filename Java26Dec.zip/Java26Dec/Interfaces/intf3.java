package Interfaces;

interface E{
	
	void show();
	default void q() {
		System.out.println("q() in E");
	}
	
}

interface F{
	void m();
	default void q() {
		System.out.println("q() in F");
	}
	static void r() {
		System.out.println("r() in F");

	}
}

interface G extends E,F{
	void add();

	@Override
	default void q() {
		// TODO Auto-generated method stub
		F.super.q();
	}
}

class intf3 implements G{
	public void show() {
		System.out.println("class intf3 show()");
		
	
	}
	
	public void add() {
		System.out.println("class intf3 add()");
	}
	
	public void m() {
		System.out.println("class intf3 m()");
	}
	
	public static void main(String args[]) {
		
		intf3 d3 = new intf3();
		d3.show();
		d3.m();
		d3.q();
		F.r();
		d3.add();
	}
	
}