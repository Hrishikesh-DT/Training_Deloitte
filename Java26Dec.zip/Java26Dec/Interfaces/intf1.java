package Interfaces;

interface A{
	
	void show();
}

class intf1 implements A{
	public void show() {
		System.out.println("class D show()");
		
	
	}
	
	public static void main(String args[]) {
		
		intf1	d1 = new intf1();
		d1.show();
	}
	
}