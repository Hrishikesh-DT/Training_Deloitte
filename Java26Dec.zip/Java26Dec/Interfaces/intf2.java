package Interfaces;

interface C{
	
	void show();
}

interface D{
	void m();
}

class intf2 implements C,D{
	public void show() {
		System.out.println("class intf2 show()");
		
	
	}
	
	public void m() {
		System.out.println("class intf2 m()");
	}
	
	public static void main(String args[]) {
		
		intf2 d2 = new intf2();
		d2.show();
		d2.m();
	}
	
}