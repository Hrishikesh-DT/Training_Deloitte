abstract class AA{
	
	abstract void show();
}


abstract class BB extends AA{
	/*void show() {
		System.out.println("Class B");
	}*/
	
}

class abst_multilevel extends BB{
	
	void show() {
		System.out.println("Class abst_multilevel");
	}
	
	public static void main(String args[]) {
		
		abst_multilevel a2 = new abst_multilevel();
		a2.show();
	}
	
	
}