abstract class A{
	
	abstract void show();
}

class Abstract_keyword extends A{
	
	void show() {
		System.out.println("Class Abstract_keyword");
	}
	
	public static void main(String args[]) {
		
		Abstract_keyword a1 = new Abstract_keyword();
		a1.show();
	}
	
	
}