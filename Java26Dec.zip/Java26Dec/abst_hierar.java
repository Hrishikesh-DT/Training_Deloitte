abstract class AAA
{
	
	abstract void show();
}


class BBB extends AAA
{
	void show() 
	{
		System.out.println("Class B");
	}
	
}

class abst_hierar extends AAA{
	
	void show() 
	{
		System.out.println("Class abst_hierar");
	}
	
	public static void main(String args[])
	{
		
		abst_hierar a3 = new abst_hierar();
		a3.show();
		AAA a4 = new BBB();
		a4.show();
	}
	
	
}