package Exceptn;

class try_c_finally{
	
	int z;
	int a[] = {2,4,6};
	void div()
	{
		try {
			
		
		z = a[6]/0;
		System.out.println("z="+z);
		}
		catch(ArithmeticException e) {
			System.out.println("divide by 0 not allowed");
		}
		catch(ArrayIndexOutOfBoundsException e) {
			System.out.println("Array index incorrect!");

		}
		finally {
			System.out.println("Finally block");
		}
	}
	
	
	
	
	public static void main(String[] args) {
		try_c_finally p =new try_c_finally();
		System.out.println("Hello");
		p.div();
		System.out.println("bye");
	}
	
	
	
}