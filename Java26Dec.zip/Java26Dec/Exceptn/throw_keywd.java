package Exceptn;
class throw_keywd{
	
	int z;
	int a[] = {2,4,6};
	void div() throws ArithmeticException,ArrayIndexOutOfBoundsException
	{
		try {
		z = a[6]/0;
		System.out.println("z="+z);
		}
		catch(ArithmeticException e) {
			System.out.println("throwing arithmetic exception");
			throw e;
		}
		catch(ArrayIndexOutOfBoundsException e) {
			System.out.println("throwing array out of bound exception");
			throw e;
		}
		
	}
	
	
	
	
	public static void main(String[] args) {
		throw_keywd p =new throw_keywd();
		System.out.println("Hello");
		
		try {
		p.div();}
		catch(ArithmeticException e) {
			System.out.println("divide by 0 not allowed");
		}
		catch(ArrayIndexOutOfBoundsException e) {
			System.out.println("Array index incorrect!");

		}
		finally {
			System.out.println("Finally block");
		}
		System.out.println("bye");
	}
	
	
	
}