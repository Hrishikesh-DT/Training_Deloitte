package Exceptn;

class throws_keyword{
	
	int z;
	int a[] = {2,4,6};
	void div() throws ArithmeticException,ArrayIndexOutOfBoundsException
	{
		
		z = a[6]/0;
		System.out.println("z="+z);
	
		
	}
	
	
	
	
	public static void main(String[] args) {
		throws_keyword p =new throws_keyword();
		System.out.println("Hello");
		
		try {
		p.div();}
		catch(ArithmeticException e) {
			System.out.println("divide by 0 not allowed");
		}
		catch(ArrayIndexOutOfBoundsException e) {
			System.out.println("Array index incorrect!");

		}
		finally {
			System.out.println("Finally block");
		}
		System.out.println("bye");
	}
	
	
	
}