package Exceptn;

class try_catch{
	
	int z;
	int a[] = {2,4,6};
	void div()
	{
		try {
			
		
		z = a[6]/0;
		System.out.println("z="+z);
		}
		catch(ArithmeticException e) {
			System.out.println("divide by 0 not allowed");
		}
		catch(ArrayIndexOutOfBoundsException e) {
			System.out.println("Array index incorrect!");

		}
	}
	
	
	
	
	public static void main(String[] args) {
		try_catch p =new try_catch();
		p.div();
		
	}
	
	
	
}