package Exceptn;

class DivideBy7Exception extends Exception {

    /*public DivideBy7Exception(String message) {
        System.out.print(message);
    }
    */
    public String toString() {
    	return "MY CUSTOM EXCEPTION: --> DIVIDE BY 7 NOT ALLOWED";
    }
}


class Custom_exceptn{
	
	int z,divisor;
	int a[] = {2,4,6};
	void div() //throws ArithmeticException,ArrayIndexOutOfBoundsException,DivideBy7Exception
	{
		divisor = 7;
		try {
			if(divisor == 7) {
				throw new DivideBy7Exception();
			}
			
		z = a[2]/divisor;
		System.out.println("z="+z);
		}
		catch(DivideBy7Exception e) {
			System.out.println("Divide by 7 exception occurred.");
			System.out.println(e);
		}
		catch(ArithmeticException e) {
			System.out.println("throwing arithmetic exception");
			//throw e;
		}
		catch(ArrayIndexOutOfBoundsException e) {
			System.out.println("throwing array out of bound exception");
			//throw e;
		}
		finally {
			System.out.println("Finally block");
		}
		
	}
	
	
	
	
	public static void main(String[] args) {
		Custom_exceptn p =new Custom_exceptn();
		System.out.println("Hello");
		
		
		p.div();
		
		
		System.out.println("bye");
	}
	
	
	
}