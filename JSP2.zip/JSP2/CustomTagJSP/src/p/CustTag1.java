package p;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import java.io.*;


public class CustTag1 extends TagSupport {
	public int doStartTag() throws JspTagException
	{
		
		try {
			
			JspWriter out = pageContext.getOut();
			out.println("<br><b>Welcome custom tag</b><br>");
		}
		catch(Exception e){}
			return SKIP_BODY;
	}
	
	public int doEndTag() throws JspTagException
	{
		return EVAL_PAGE;
	}
	
}
