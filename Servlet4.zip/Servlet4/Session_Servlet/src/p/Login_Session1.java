package p;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Login_Session1 extends HttpServlet{
	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response){
		
		
		try {
			PrintWriter out = response.getWriter();
			String uname = request.getParameter("uname");
			String passwd = request.getParameter("password");
			
			HttpSession ses = request.getSession(true);
			
			
			if(uname.equals("abc"))
			{
				out.print("Welcome user!"+uname);
				ses.setAttribute("user",uname);
				out.print("<br>Login page id = "+ses.getId());
				out.println("<br>Session Id: ");
				out.print(ses.getId());
				out.print("<br>Creation time: ");
				out.print(new Date(ses.getCreationTime()));
				out.print("<br>Last Access time: ");
				out.print(new Date(ses.getLastAccessedTime()));
				out.print("<br>Maximum Inactive interval (seconds): ");
				out.print(ses.getMaxInactiveInterval());
				out.print("<br><a href='/Session_Servlet/2'>Visit</a>");
			}
			else
			{
				
				RequestDispatcher rd = request.getRequestDispatcher("index.html");
				out.print("<font color=red>Incorrect username or password</font>");
				rd.include(request,response);
			}
			
			}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}

}

