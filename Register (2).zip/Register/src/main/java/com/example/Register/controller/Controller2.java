package com.example.Register.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttribute;
import org.springframework.web.bind.annotation.SessionAttributes;

@Controller
@SessionAttributes("uname")
public class Controller2 {

	@RequestMapping("/v")
	public String view4(@ModelAttribute("uname")String uname,ModelMap m)
	{
		
		m.put("uname",uname);
		return "Third";
	}
}
