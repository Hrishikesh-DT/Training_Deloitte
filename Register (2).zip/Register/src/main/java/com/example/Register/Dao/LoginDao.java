package com.example.Register.Dao;

import java.util.*;
import org.springframework.data.domain.Sort;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.Register.Entity.*;

@Service
public class LoginDao{

	@Autowired
	UsersRepository ur;
	
	List<Users> lup;//not used
	
	public Boolean get_Dao_validate(String uname,String password)
	{
		if(uname.equals("Hrishi") && password.equals("1234"))
		{
			return true;
		}
		else
			return false;
	}
	
	
	
	public List<Users> listAll()
	{
		return ur.findAll();
	}
	
	
    public List<Users> listAllSorted() {
        return ur.findAll(Sort.by(Sort.DEFAULT_DIRECTION.ASC,"username"));
    }

	
    
	public Users getId(String username)
	{
		Users u_temp = ur.findById(username).get();
		System.out.println("\n\nPassword is:  "+u_temp.getPassword()+" \n\n\n");
		return u_temp ;
	}
	
	public void saveUser(Users ut)
	{
		ur.save(ut);
	}
	
	public void deleteUser(String username)
	{
		ur.deleteById(username);
	}
	
	public boolean checkUserExists(List<Users> lu,String uname)
	{
		Iterator itr= lu.iterator();
		Users u;
		
		while(itr.hasNext())
		{
			u = (Users)itr.next();
			if(u.getUsername().equals(uname))
			{
				return true;
			}
			
		}
		System.out.println("\nNo user found in DAO \n");
		return false;
	}
	
}
