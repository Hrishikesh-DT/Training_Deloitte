package p;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Delete_Servlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response){
		
		Connection conn = null;
		String url = "jdbc:mysql://localhost:3306/";
		String dbName = "db1";
		String driver = "com.mysql.jdbc.Driver";
		String username = "root";
		String password = "root";
		try {
			PrintWriter out = response.getWriter();
			
			Class.forName(driver);
			conn = DriverManager.getConnection(url+dbName,username,password);
			//Statement sm = conn.createStatement();
			out.print("Connected to database! again<br>");
			
			
			PreparedStatement ps = conn.prepareStatement("delete from emp3 where ecode = ?");
			//Scanner sc = new Scanner(System.in);
			String ecode =request.getParameter("fname");
			//String ename =request.getParameter("fname2");
			
			ps.setString(1,ecode);
			//ps.setString(2,ecode);
			
			int x  = ps.executeUpdate();
			out.print(x +" rows deleted<br>");
			Statement sm = conn.createStatement();
			ResultSet rs = sm.executeQuery("select * from emp3");
			
			//ResultSet rs = sm.executeQuery("select * from emp3");
			out.print("<table border=1 bgcolor=lightblue>");
			out.print("<th>ECODE</th><th>EName</th>");
			
			while(rs.next())
			{
				String f1 =rs.getString(1);
				String f2 = rs.getString(2);
				out.print("<tr><td>"+f1+"</td><td>"+f2+"</td></tr>");
				//System.out.println(f2);
			}
			
			out.print("</table>");
			
			conn.close();
			out.print("Disconnected from database.");
			
			}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}

}
