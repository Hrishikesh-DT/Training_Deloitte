package rd;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class F2 extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response){
		
		
		try {
			PrintWriter out = response.getWriter();
			String uname =request.getParameter("uname");
			String password =request.getParameter("password");
			out.print("<br>Welcome Sir "+uname+" !!");
			
			}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
		      throws ServletException, IOException {
		      
		      doGet(request, response);
		   }

}
