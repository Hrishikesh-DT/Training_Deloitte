package p;

import org.springframework.stereotype.Service;

@Service
public class FService {

	public String SMsg()
	{
		return "Service msg";
	}
}

