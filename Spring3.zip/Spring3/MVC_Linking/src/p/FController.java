package p;

import java.awt.List;
import java.util.*;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/cl")
public class FController {
	
	
	@RequestMapping("/v1")
	public ModelAndView dis1()
	{

		return new ModelAndView("First","msg","Hello Welcome user Hrishikesh!!");
	}
	
	@RequestMapping("/v2")
	public ModelAndView dis2()
	{

		return new ModelAndView("Second","msg","Insert page");
	}
	
	@RequestMapping("/v3")
	public ModelAndView dis3()
	{

		return new ModelAndView("Third","msg","Update page");
	}
	
}
