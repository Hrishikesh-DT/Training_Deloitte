package p;
import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class LoginService {

	@Autowired
	Dao d;
	List<Login> l;
	public List<Login> getData()
	{		
		 return d.getL();
		
	}
	
	public void addLoginSer(Login lgn)
	{
		d.addLogin(lgn);
	}

	public List<Login> editX(String id)
	{
		l=d.editData(id);
		return l;
	}
	
	public List<Login> delX(String id)
	{
		l=d.delData(id);
		return l;
	}
	
}
