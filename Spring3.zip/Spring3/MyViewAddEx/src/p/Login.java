package p;

public class Login {

	public Login() {}
	
	public Login( String id,String ename, String ecode) {
		super();
		this.ename = ename;
		this.ecode = ecode;
		this.id = id;
	}

	String ename,ecode,id;

	public String getEname() {
		return ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	public String getEcode() {
		return ecode;
	}

	public void setEcode(String ecode) {
		this.ecode = ecode;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}
}
