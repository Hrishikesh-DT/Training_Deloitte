package p;

import java.awt.List;
import java.util.*;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class FController {
	
	@Autowired
	LoginService ls;
	
	@RequestMapping("/view")
	public String dis(ModelMap m)
	{
		ArrayList al = (ArrayList) ls.getData();
		m.addAttribute("lgobj",al);
		
		return "DisRec";
	}
	
	@RequestMapping("/add")
	public String addData(ModelMap m)
	{
		Login lg = new Login();
		m.addAttribute("lgobj",lg);
		return "AddRec";
	}
	
	@RequestMapping("/save")
	public String saveData(@ModelAttribute("lgobj") Login lgobj,ModelMap m)
	{
		m.addAttribute("lgobj",lgobj);
		ls.addLoginSer(lgobj);
		return "redirect:/view";

	}
	
	@RequestMapping("/edit/{id}")
	public String myEditData(@PathVariable String id ,ModelMap m)
	{
		ArrayList<Login> al=(ArrayList<Login>) ls.editX(id);
		m.addAttribute("lgobj",al);
	
		return "Edit";
	}

	@RequestMapping("/del/{id}")
	public String myDelData(@PathVariable String id ,ModelMap m)
	{
		ArrayList<Login> al= (ArrayList<Login>)ls.delX(id);
		return "redirect:/view";
	}
}
