package p;
import java.util.*;

import org.springframework.stereotype.Service;

@Service
public class Dao {

	List<Login> l;
	
	public List getL()
	{
		return l;
	}
	
	public void addLogin(Login lgn) 
	{
		l.add(lgn);
	}
	
	Dao()
	{
		l=new ArrayList<Login>();
		l.add(new Login("1","Hrishi","e04"));
		l.add(new Login("2","Dharni","e20"));
		l.add(new Login("3","VKS","e45"));
	}
	
	public List<Login> editData(String id)
	{
		Iterator itr= l.iterator();
		Login lgo;
		
		while(itr.hasNext())
		{
			lgo = (Login)itr.next();
			if(lgo.getId().equals(id))
			{
				lgo.setEname("Vedanta");
			}
			
		}
		
		return l;
	}
	
	public List<Login> delData(String id)
	{
		Iterator itr= l.iterator();
		Login lgo;
		
		while(itr.hasNext())
		{
			lgo = (Login)itr.next();
			if(lgo.getId().equals(id))
			{
				itr.remove();
			}
			
		}
		
		return l;
	}
}


