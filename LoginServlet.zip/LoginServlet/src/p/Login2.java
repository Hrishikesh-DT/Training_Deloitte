package p;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Login2 extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response){
		
		Connection conn = null;
		String url = "jdbc:mysql://localhost:3306/";
		String dbName = "db1";
		String driver = "com.mysql.jdbc.Driver";
		String username = "root";
		String password = "root";
		
		try {
			PrintWriter out = response.getWriter();
			
			String ecode =request.getParameter("ecode");
			String ename =request.getParameter("ename");
			String s = request.getParameter("click");
			
			
			Class.forName(driver);
			conn = DriverManager.getConnection(url+dbName,username,password);
			//Statement sm = conn.createStatement();
			out.print("Connected to database! again<br>");
			
			
			if(s.equals("update"))
			{
				out.println("Update");
				PreparedStatement ps = conn.prepareStatement("update emp3 set ename = ? where ecode=?");
				//Scanner sc = new Scanner(System.in);
				String ecode2 =request.getParameter("ecode");
				String ename2 =request.getParameter("ename");
				
				ps.setString(1,ename2);
				ps.setString(2,ecode2);
				
				int x  = ps.executeUpdate();
				out.print(x +" rows updated<br>");
				Statement sm = conn.createStatement();
				ResultSet rs = sm.executeQuery("select * from emp3");
				
				//ResultSet rs = sm.executeQuery("select * from emp3");
				out.print("<table border=1 bgcolor=lightblue>");
				out.print("<th>ECODE</th><th>EName</th>");
				
				while(rs.next())
				{
					String f1 =rs.getString(1);
					String f2 = rs.getString(2);
					out.print("<tr><td>"+f1+"</td><td>"+f2+"</td></tr>");
					//System.out.println(f2);
				}
				
				out.print("</table>");
				
				conn.close();
				out.print("Disconnected from database.");
				
			}
			else
			{
				out.println("delete");
				PreparedStatement ps = conn.prepareStatement("delete from emp3 where ecode = ?");
				//Scanner sc = new Scanner(System.in);
				String ecode3 =request.getParameter("ecode");
				//String ename =request.getParameter("fname2");
				
				ps.setString(1,ecode3);
				//ps.setString(2,ecode);
				
				int x  = ps.executeUpdate();
				out.print(x +" rows deleted<br>");
				Statement sm = conn.createStatement();
				ResultSet rs = sm.executeQuery("select * from emp3");
				
				//ResultSet rs = sm.executeQuery("select * from emp3");
				out.print("<table border=1 bgcolor=lightblue>");
				out.print("<th>ECODE</th><th>EName</th>");
				
				while(rs.next())
				{
					String f1 =rs.getString(1);
					String f2 = rs.getString(2);
					out.print("<tr><td>"+f1+"</td><td>"+f2+"</td></tr>");
					//System.out.println(f2);
				}
				
				out.print("</table>");
				
				conn.close();
				out.print("Disconnected from database.");
			}
			
			}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}

}
