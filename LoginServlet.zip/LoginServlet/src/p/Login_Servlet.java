package p;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Login_Servlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response){
		
		
		try {
			PrintWriter out = response.getWriter();
			
			String uname =request.getParameter("uname");
			String password =request.getParameter("password");
			if(uname.equals("abc") && (password.equals("abc")))
			{
				out.println("Valid User");
				out.println("<html><body>");
				out.println("<form name='ii' method='get' action='pass2'>");
				out.println("Ecode: <input type=\"text\" name=\"ecode\"><br>");
				out.println("Ename:<input type=\"text\" name=\"ename\"><br>");
				out.println("<br><input type=\"submit\" value=\"update\" name =\"click\">");
				out.println("<input type=\"submit\" value=\"delete\" name=\"click\">");
				out.println("</form>");
				out.println("</body></html>");
			}
			else
			{
				out.println("INVALID USER!!");
			}
			
			}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}

}
