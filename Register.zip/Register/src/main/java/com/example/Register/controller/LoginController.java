package com.example.Register.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.example.Register.Entity.Users;
import com.example.Register.service.LoginService;

@Controller
@SessionAttributes("uname")
public class LoginController 
{
	@Autowired
	LoginService ls;
	
	@RequestMapping("/")
	public String view(Model model)
	{
	
		System.out.println("Going to first login");
		return "index";
	}
	
	
	@RequestMapping("/pass")
	public String view1(@RequestParam("uname")String uname,@RequestParam("password")String password,ModelMap m)
	{
		
		m.put("uname",uname);
		//Checking if user exists
		List<Users> lu=ls.listSortedService();
		if(ls.checkUserExistsService(lu,uname))
		{
			System.out.println("\n\nValid username....\n\n");
		}
		else
		{
			return "Invalid_user";
		}
		
		
		String actual_passwd = ls.getIdService(uname);
		
		if(actual_passwd.equals(password))
		{
			return "Second";
		}
		else
		{
			return "Invalid_user";
		}
		/*
		if(ls.validate(uname,password))
		{
			System.out.println("Valid user");
			return "Second";
		}
		else{
			return "Invalid_user";
		}
		*/
	}
	
	@RequestMapping("/disAll")
	public String view5(Model model)
	{
		List<Users> lu=ls.listSortedService();
		model.addAttribute("lstUsers",lu);
		
		return "DisplayAll";
	}
	
	/*
	@RequestMapping("/v")
	public String view2(ModelMap m)
	{
		
		m.put("s1",uname);
		m.put("s2", password);
		return "Third";
	}
	*/
	
	@RequestMapping(value="/newuser")
	public String showNewContactPage(Model model) //for new record
	{
		Users ut=new Users();
		model.addAttribute("UsersObj",ut);
		
		return "NewUserRegister";
	}
	
	@RequestMapping(value="/save")//for new record and update
	public String saveNewUser(@ModelAttribute("UsersObj") Users UsersObj)
	{
		ls.saveUserService(UsersObj);
		
		return "redirect:/";
		//return "NewFile";//it's working 
	}
	
}

