package com.example.Register.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Register.Dao.LoginDao;
import com.example.Register.Entity.Users;

import javassist.bytecode.Descriptor.Iterator;

@Service
public class LoginService {

	@Autowired
	LoginDao ld;
	
	
	
	public Boolean validate(String uname,String password)
	{
		return ld.get_Dao_validate(uname, password);
	}
	
	public List<Users> listSortedService()
	{
		List<Users> lc=ld.listAllSorted();
		
		return lc;
	}
	
	public String getIdService(String username)
	{
		return ld.getId(username).getPassword();
	}
	
	public boolean checkUserExistsService(List<Users> lu,String uname)
	{
		return ld.checkUserExists(lu,uname);
	}
	
	public void saveUserService(Users UsersObj)
	{
		ld.saveUser(UsersObj);
	}
}
