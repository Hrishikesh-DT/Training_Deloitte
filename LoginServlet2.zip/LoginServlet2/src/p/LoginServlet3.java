package p;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.*;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class LoginServlet3 extends HttpServlet {
	
	ServletContext ctx = null;
	public void init(ServletConfig sc) throws ServletException
	{
		ctx = sc.getServletContext();
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response){
		
		
		try {
			PrintWriter out = response.getWriter();
			
			String s1=null;
			String uname = (String)ctx.getAttribute("ob");
			//String uname = null;
			/*
			Cookie cr[] = request.getCookies();
			
			if(cr!= null)
			{
				for (int i=0;i<cr.length;i++)
				{
				s1 = cr[i].getName();
				uname= cr[i].getValue();
				//out.print("Hello "+s+" "+s1);
				}
			}
			*/
			
			
			
			out.print("<br>Welcome Sir "+uname+" !!<br><br>");
			String s = request.getParameter("click");
			
			out.println("<html><body>");
			out.println("<form name='ii' method='get' action='pass2'>");
			out.println("Ecode: <input type=\"text\" name=\"ecode\"><br>");
			out.println("Ename:<input type=\"text\" name=\"ename\"><br>");
			out.println("<input type=\"submit\" value=\"Go\" name=\"click\">");
			out.print("<input type='hidden' value= '"+s+"' name = 'hh'>");
			out.println("</form>");
			out.println("</body></html>");
			
			
			
			
			}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}

}
