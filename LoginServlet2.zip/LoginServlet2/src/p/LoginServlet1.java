package p;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class LoginServlet1 extends HttpServlet {

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response){
		
		Connection conn = null;
		String url = "jdbc:mysql://localhost:3306/";
		String dbName = "db1";
		String driver = "com.mysql.jdbc.Driver";
		String username = "root";
		String password1 = "root";
		
		try {
			PrintWriter out = response.getWriter();
			String uname =request.getParameter("uname");
			String password =request.getParameter("password");
			uname = uname.trim();
			password = password.trim();
			
			Class.forName(driver);
			conn = DriverManager.getConnection(url+dbName,username,password1);
			//Statement sm = conn.createStatement();
			//out.print("Connected to database! again<br>");
			
			RequestDispatcher rd1 = request.getRequestDispatcher("/1");
			RequestDispatcher rd2 = request.getRequestDispatcher("/2");
			
			Statement sm = conn.createStatement();
			ResultSet rs = sm.executeQuery("select * from login_details where uname='"+uname+"'");
				
			if(rs.next())
			{
				String f1 =rs.getString(1);
				String f2 = rs.getString(2);
				if(uname.equals(f1) && (password.equals(f2)))
				{
					out.println("Valid User");
					rd1.include(request, response);
					
				}
				else
				{
					out.println("INVALID USER!!");
					//rd2.forward(request, response);
					response.sendRedirect("wrong_passwd.html");
				}
			}
			else
			{
				out.print("Unregistered User!!!");
				response.sendRedirect("Unregistered.html");
			}
				
			out.print("</table>");
				
			conn.close();
			//out.print("Disconnected from database.");
			
			
			
			
			
			}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
		      throws ServletException, IOException {
		      
		      doGet(request, response);
		   }

}
