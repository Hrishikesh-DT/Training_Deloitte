package p;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class LoginServlet2 extends HttpServlet {

	ServletContext ctx = null;
	public void init(ServletConfig sc) throws ServletException
	{
		ctx = sc.getServletContext();
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response){
		
		Connection conn = null;
		String url = "jdbc:mysql://localhost:3306/";
		String dbName = "db1";
		String driver = "com.mysql.jdbc.Driver";
		String username = "root";
		String password1 = "root";
		
		try {
			PrintWriter out = response.getWriter();
			String uname =request.getParameter("uname");
			ctx.setAttribute("ob", uname);
			
			String password =request.getParameter("password");
			out.print("<br>Welcome Sir "+uname+" !!<br><br>");
			/*
			Cookie cr = new Cookie("user",uname);
			response.addCookie(cr);
			*/
			//RequestDispatcher rd1 = request.getRequestDispatcher("/1");
			//RequestDispatcher rd2 = request.getRequestDispatcher("/2");
				
			out.print("<html><body>");
			out.print("<form name='f1' method='get' action='c'>");
			out.print("<input type='submit' value='display' name='click'>");
			out.print("<input type='submit' value='update' name='click'>");
			out.print("<input type='submit' value='insert' name='click'>");
			out.print("<input type='submit' value='delete' name='click'>");
			out.print("</form>");
			out.print("</body></html>");
			
			
			
			
			
			}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
		      throws ServletException, IOException {
		      
		      doGet(request, response);
		   }

}
