package p;
import java.util.*;
import org.hibernate.cfg.Configuration;
import org.hibernate.SessionFactory;
import org.hibernate.*;
import org.hibernate.Transaction;

public class EmpHiber {

	public static void main(String[] args) {

		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory sf =cfg.buildSessionFactory();
		
		Session ses = sf.openSession();
		Transaction ts = ses.beginTransaction();
		ts.begin();
		
		ReqEmp re = new ReqEmp();
		re.setId(7);
		re.setEname("Hrishi");
		re.setBonus(5000);
		re.setSal(30000);
		ses.persist(re);
		
		ses.flush();
		ses.clear();
		
		ConEmp ce = new ConEmp();
		ce.setEname("Dharni");
		ce.setId(9);
		ce.setPay(20000);
		ce.setPeriod("5");
		ses.save(ce);
		
		ts.commit();
		ses.clear();
		ses.close();
		System.out.println("Success!");
		
	}

}
