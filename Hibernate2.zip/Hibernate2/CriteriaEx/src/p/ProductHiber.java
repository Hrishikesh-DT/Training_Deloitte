package p;
import java.util.*;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;
import org.hibernate.SessionFactory;
import org.hibernate.*;
import org.hibernate.Transaction;

public class ProductHiber {

	public static void main(String[] args) {

		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory sf =cfg.buildSessionFactory();
		
		Session ses = sf.openSession();
		//Transaction ts = ses.beginTransaction();
		//ts.begin();
		
		Criteria crit = ses.createCriteria(Product.class);
		Criterion cn = Restrictions.ge("price",Double.valueOf(15000));
		
		crit.add(cn);
		List l = crit.list();
		System.out.print("List total size :"+l.size());
		Iterator it = l.iterator();
		
		while(it.hasNext())
		{
			Product p = (Product)it.next();
			System.out.println(" \n"+p.getProductId());
			System.out.println(" "+p.getProName());
			System.out.println(" "+p.getPrice());
			System.out.println("------");
		}
		
		ses.close();
		sf.close();
	}

}
