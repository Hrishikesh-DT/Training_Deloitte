package p;
import java.util.*;
import org.hibernate.cfg.Configuration;
import org.hibernate.SessionFactory;
import org.hibernate.*;
import org.hibernate.Transaction;

public class EmpHiber {

	public static void main(String[] args) {

		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory sf =cfg.buildSessionFactory();
		
		Session ses = sf.openSession();
		Transaction ts = ses.beginTransaction();
		ts.begin();
		
		
		//INSERT QUERY
		Emp1 e1=new Emp1();
		e1.setId("41");
		e1.setEcode("E75");
		e1.setEname("Aastha");
		e1.setSalary(16000);
		//ses.persist(e1);
		String eid = (String)ses.save(e1);
		//System.out.println("eid= "+eid);
		ts.commit();
		
		
		/*
		//SELECT QUERY
		List e = ses.createQuery("from Emp1").list();
		Iterator itr = e.iterator();
		while(itr.hasNext())
		{
			Emp1 em1 = (Emp1)itr.next();
			System.out.println("eid = "+em1.getId());
			System.out.println("ecode= "+em1.getEcode());
		}
		ts.commit();
		*/
		
		/*
		//UPDATE QUERY
		Emp1 emp1 = (Emp1)ses.get(Emp1.class, "48");
		emp1.setSalary(20000);
		ses.update(emp1);
		ts.commit();
		*/
		
		/*
		//DELETE QUERY
		Object o = ses.load(Emp1.class, new String("40"));
		Emp1 emp2 = (Emp1)o;
		ses.delete(emp2);
		ts.commit();
		System.out.println("deleted successfully");
		*/
		
		
	}

}
