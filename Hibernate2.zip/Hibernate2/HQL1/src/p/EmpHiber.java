package p;
import java.util.*;
import org.hibernate.cfg.Configuration;
import org.hibernate.SessionFactory;
import org.hibernate.*;
import org.hibernate.Transaction;

public class EmpHiber {

	public static void main(String[] args) {

		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory sf =cfg.buildSessionFactory();
		
		Session ses = sf.openSession();
		Transaction ts = ses.beginTransaction();
		ts.begin();
		/*
		Query query = ses.createQuery("from Emp1");
		List e1 = query.list();
		Iterator itr = e1.iterator();
		while(itr.hasNext())
		{
			Emp1 em1 = (Emp1)itr.next();
			System.out.println("eid = "+em1.getId());
			System.out.println("ecode= "+em1.getEcode());
		}
		ts.commit();
		*/
		
		/*
		//	hql--update
		Query q = ses.createQuery("update Emp1 set ename=:n where id=:i");
		q.setParameter("n", "Dharni");
		q.setParameter("i", "46");
		int z = q.executeUpdate();
		System.out.print("z= "+z);
		ts.commit();
		*/
		
		/*
		//	hql--delete
		String s ="40";
		Query query = ses.createQuery("delete from Emp1 where id='"+s+"'");
		int z = query.executeUpdate();
		System.out.print("z= "+z);
		ts.commit();
		*/
		
		//AGGREGATE FUNCTIONS
		Query q = ses.createQuery("select sum(salary) from Emp1");
		List<Integer> list = q.list();
		System.out.println("sum= "+list.get(0));
		
		
		Query q1 = ses.createQuery("select avg(salary) from Emp1");
		List<Integer> list2 = q1.list();
		System.out.println("avg= "+list2.get(0));
		
		Query q2 = ses.createQuery("select max(salary) from Emp1");
		List<Integer> list3 = q2.list();
		System.out.println("max= "+list3.get(0));
		
		Query q3 = ses.createQuery("select min(salary) from Emp1");
		List<Integer> list4 = q3.list();
		System.out.println("min= "+list4.get(0));
		ts.commit();
	}

}
