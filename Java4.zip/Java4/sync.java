class A
{
	void s()
	{
		System.out.println("child thread "+Thread.currentThread().getId() +" says hello");
		try{
			Thread.sleep(1000);
			
		}
		catch(InterruptedException e)
		{
			System.out.println("child thread "+Thread.currentThread().getId() +" interrupted hello");
			
		}
		System.out.println("child thread "+Thread.currentThread().getId() +" says bye");
	}
	
	
	void s2()
	{
		System.out.println("s2");
	}
}



class Demo implements Runnable
{
	int i;
	A a;
	Demo(A a)
	{
		this.a=a;
	}
	
	public void run()
	{
		synchronized(a)
		{
			a.s();
		}
		
	}
	 
	
	
}


class sync{
	public static void main(String args[]){
		
		A a1 = new A();
		
		
		Demo d = new Demo(a1);
		Thread t,t1;
		t = new Thread(d);
		t.start();
		t1 = new Thread(d,"two");
		t1.start();
		
	}
}