class Demo extends Thread
{
	int i;
	Demo()
	{
		start();
	}
	
	public void run()
	{
		for(i=0;i<5;i++)
		{
			System.out.println("child thread "+Thread.currentThread().getId() +" i="+i);
			System.out.println("child thread "+Thread.currentThread().getId() +" finished");
		}
	}
	
}


class Thread_cls{
	public static void main(String args[]){
		Demo d = new Demo();
		Demo d1 = new Demo();
		
	}
}