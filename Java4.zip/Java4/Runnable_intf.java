class Demo implements Runnable
{
	int i;
	
	
	public void run()
	{
		for(i=0;i<5;i++)
		{
			System.out.println("child thread "+Thread.currentThread().getId() +" i="+i);
			System.out.println("child thread "+Thread.currentThread().getId() +" finished");
		}
	}
	
}


class Runnable_intf{
	public static void main(String args[]){
		Demo d = new Demo();
		Demo d1 = new Demo();
		Thread t = new Thread(d);
		Thread t1 = new Thread(d1);
		t.start();
		t1.start();
		
	}
}