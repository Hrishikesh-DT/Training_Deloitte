class For_each_nested
{
	public static void main(String ar[])
	{
		int x[][]={{10,20,9},{23,4},{2,65,68,34}};
		for(int i[]:x)
		{
			for(int j :i)
				System.out.println(j);
		}
	}
	
	
}