class String_equality{
	
	public static void main(String args[])
	{
		String s ="hello";
		String s1="hello";
		String s2 = new String("hello");
		String s3 = new String("hello");
		StringBuffer sb = new StringBuffer("hello");
		System.out.println("s.equals(s1): " +s.equals(s1) );
		System.out.println("s.equals(s2): " +s.equals(s2) );
		System.out.println("s2.equals(s3): " +s2.equals(s3) );
		System.out.println("s==s1: " +(s==s1) );
		System.out.println("s1==s2 : " +(s1==s2) );
		System.out.println("s3==s2 : " +(s3==s2) );	
		System.out.println("sb.equals(s3): " +sb.equals(s3));
		
	}
	
	
	
	
}