class String_Buffer{
	
	public static void main(String args[])
	{
		String s ="hello";
		String s1="hello";
		String s2 = new String("hello");
		String s3 = new String("hello");
		StringBuffer sb = new StringBuffer("hello world");
		System.out.println("Before deletion: "+sb);

		sb = sb.delete(4,8);
		System.out.println("After deletion: "+sb);
		sb=sb.append(s);
		System.out.println("After append: "+sb);	
		
		
	}
	
	
	
	
}