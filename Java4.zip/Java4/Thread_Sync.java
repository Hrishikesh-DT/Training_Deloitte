class Demo implements Runnable
{
	int i;
	
	
	public void run()
	{
		show();
		
	}
	
	synchronized void show()
	{
		System.out.println("child thread "+Thread.currentThread().getId() +" says hello");
		try{
			Thread.sleep(1000);
			
		}
		catch(InterruptedException e)
		{
			System.out.println("child thread "+Thread.currentThread().getId() +" interrupted hello");
			
		}
		System.out.println("child thread "+Thread.currentThread().getId() +" says bye");
		
	}
	
}


class Thread_Sync{
	public static void main(String args[]){
		Demo d = new Demo();
		Demo d1 = new Demo();
		Thread t = new Thread(d);
		Thread t1 = new Thread(d);
		t.start();
		t1.start();
		
	}
}