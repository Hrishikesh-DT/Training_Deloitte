package p;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class FController {
	/*
	@RequestMapping("/v1")
	public String show(HttpServletRequest req,Model m)
	{
		String en = req.getParameter("ename");
		String sal = req.getParameter("salary");

		m.addAttribute("s1",en);
		m.addAttribute("s2",sal);
		return "First";
	}
	*/
	/*
	@RequestMapping("/v1")
	public String show(HttpServletRequest req,ModelMap m)
	{
		String en = req.getParameter("ename");
		String sal = req.getParameter("salary");

		m.put("s1",en);
		m.put("s2",sal);
		return "First";
	}
	*/
	
	@RequestMapping("/v3")
	public String show3(@RequestParam("ename")String ename,@RequestParam("salary")String salary,Model m)
	{
		
		m.addAttribute("s1",ename);
		m.addAttribute("s2",salary);
		return "First";
	}
	
}
