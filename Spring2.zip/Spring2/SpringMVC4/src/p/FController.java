package p;

import java.awt.List;
import java.util.*;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class FController {
	
	
	@RequestMapping("/v")
	public ModelAndView displayEmp()
	{
		ArrayList l = new ArrayList();
		l.add(new Emp("abc",9000));
		l.add(new Emp("ppp",7000));
	
		return new ModelAndView("view","list1",l);
	}
	
	@RequestMapping("/ef")
	public ModelAndView formTry()
	{
		Emp e= new Emp("www",888);
		return new ModelAndView("empform","empobj",e);
	}
}
