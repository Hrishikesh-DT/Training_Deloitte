package p;

public class OP {

	public void msg() {System.out.println("msg method invoked");}
	
	public int m() {
		System.out.println("m method invoked");
		return 23;
	}
	
	public void validate(int age) throws Exception
{

		if(age<18)
		{
			throw new ArithmeticException("Not valig age");
		}
		else
		{
			System.out.println("Thanks for vote");
		}
}
}
