package p;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;

@Aspect
public class ASP1 {

	@Pointcut("execution(*  OP.*(..))")
	public void pc() {}//pointcut name
	
	
	@Before("pc()")//applying pointcut on before advice
	public void myadviceex(JoinPoint jp)//it is advice (before advice)
	{
		System.out.println("before joint point, it's an example");
		
		System.out.println("Method Signature: "+ jp.getSignature());
	}
	
	
	/*
	@After("pc()")
	public void myafteradvice(JoinPoint jp)
	{
		System.out.println("After joint point");
	}
	
	*/
	/*
	@AfterReturning(pointcut = "pc()",returning= "x")//returning and objectname(in parameter)
	public void afterReturningAdvice(Object x)
	{
		System.out.println("Returning int: "+x);
	}
	
	@AfterThrowing(pointcut = "pc()",throwing="ex")
	public void AfterThrowingAdvice(ArithmeticException ex)
	{
		System.out.println("There has been an exception: "+  ex.toString());
	}
	
	@Around("pc()")
	public Object myAroundAdvice(ProceedingJoinPoint pjp) throws Throwable
	{
		System.out.println("Additional concern before calling actual method");
		Object obj =pjp.proceed();
		System.out.println("Additional concern after calling actual method");
		return obj;
	}
	*/
	
}
