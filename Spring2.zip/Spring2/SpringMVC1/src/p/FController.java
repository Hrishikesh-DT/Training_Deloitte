package p;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class FController {

	@RequestMapping("/v1")
	public String show()
	{
		System.out.println("hello");
		return "First";
	}
}
