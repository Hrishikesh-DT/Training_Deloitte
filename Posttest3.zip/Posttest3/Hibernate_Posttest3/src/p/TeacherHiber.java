package p;
import java.util.*;
import org.hibernate.cfg.Configuration;
import org.hibernate.SessionFactory;
import org.hibernate.*;
import org.hibernate.Transaction;

public class TeacherHiber {

	public static void main(String[] args) {

		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory sf =cfg.buildSessionFactory();
		
		Session ses = sf.openSession();
		Transaction ts = ses.beginTransaction();
		ts.begin();
		
		Dept d1 = new Dept();
		d1.setDid("d002");
		d1.setDname("EXTC");
		d1.setTid("t005");
		d1.setTname("PPQ");
		d1.setDept("dep1");
		ses.persist(d1);
		
		ses.flush();
		ses.clear();
		
		Course ce = new Course();
		ce.setCid("C001");
		ce.setCname("Microprocessors");
		ce.setTid("t004");
		ce.setTname("BCD");
		ce.setDept("dep2");
		ses.save(ce);
		
		ts.commit();
		ses.clear();
		ses.close();
		System.out.println("Success!");
		
	}

}
