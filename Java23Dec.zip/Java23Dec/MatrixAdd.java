class MatrixAdd{
	public static void main(String args[]){
		int x[][] = {{1,2,3},{4,5,6},{7,8,9}};
		int y[][] = {{1,2,3},{4,5,6},{7,8,9}};
		int z[][] = new int[3][3];
		for(int i = 0;i<z.length;i++){
			for(int j =0;j<z[i].length;j++){
				z[i][j] = x[i][j] + y[i][j];
				
			}
		}
		
		//print resultant matrix
		for(int i = 0;i<z.length;i++){
			for(int j =0;j<z[i].length;j++){
				System.out.print(z[i][j] +"\t");
				
			}
			System.out.println("");
		}
	}
}