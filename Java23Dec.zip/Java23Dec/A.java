class D
{
	void dis()
	{
		System.out.println("dis()");
	}

}


class C
{
	int x;
	static int p= 100;
	void show()
	{
		x=10;
		System.out.println("show()");
		System.out.println("x = "+ x);
	}
	int add(int a,int b)
	{

		return a+b;
	}
	public static void main(String ar[])
	{
		/*
		System.out.println("hello");
		C c1 = new C();
		c1.show();
		System.out.println("x in main = " + c1.x);
		D d1 = new D();
		d1.dis();
		int x = Integer.parseInt(ar[0]);
		int y = Integer.parseInt(ar[1]);
		int z = c1.add(x,y);
		
		System.out.println("Addition of "+ x +" and "+ y+" = "+z);
		System.out.println("p in main = "+p);
		*/
		
		int marks = Integer.parseInt(ar[0]);
		if(marks > 50)
		{
			System.out.println("Pass");
		}
		else{
			System.out.println("Fail");
		}


if (marks>=90)
{System.out.println("Grade = A");
}
else if(marks>=80 && marks<90)
{System.out.println("Grade = B");
}
else if(marks>=70 && marks<80)
{System.out.println("Grade = C");
}
else if(marks>=60 && marks<70)
{System.out.println("Grade = D");
}
else
{System.out.println("Grade = F");
}
	}
}