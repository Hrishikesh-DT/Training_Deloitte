class Books{
	int id;
	public static void main(String[] args){
		int count = 0;
		Books b[] = new Books[2];
		for (int i =0;i<2;i++){
			b[i] = new Books();
		}
		for (int i = 0;i<2;i++){
			b[i].id = ++count;
		}
		
		for (int i =0;i<2;i++){
			System.out.println("id["+i+"]="+b[i].id);
		}
		
	}
	
	
}