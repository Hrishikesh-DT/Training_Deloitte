class Loop{
	
	void print1To10(){
		for(int i =1; i<=10; i++){
			System.out.println(i);
		}
	}
	
	void print10To1(){
		for(int i =10; i>0; i--){
			System.out.println(i);
		}
	}
	
	void print1sstTenEvenNos(){
		int count=0;
		int i =0;
		while(count<10){
			if(i%2 == 0){System.out.println(i);count++;}
			i++;
			
			
		}
	}
	
	void printStars(){
		for(int i =1; i<=3; i++){
			for(int j = 1;j<=i;j++){
			System.out.print("*");
			}
			System.out.println("");
		}
	}
	
	public static void main(String ar[])
	{
		Loop a1 = new Loop();
		a1.print1To10();
		a1.print10To1();
		a1.print1sstTenEvenNos();
		a1.printStars();
	}
	
	
	
}